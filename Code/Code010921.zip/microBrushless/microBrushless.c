/*###########################################################################

    Auteur      : Joan Bommottet
    Version     : 0.0
    Date        : 01.09.2021
    Fichier     : microBrushless.c
    Description : Programme du DSP TMS320F28388D pour la commande de moteurs
                  brushless. Ce fichier contient :
                  - Le main
                  - Les fonctions d'initialisations des modules utilis�s
                      - Les ADCs
                      - Les PWMs
                      - Le module EQEP
                  - Les interruptions
                      - des ADCs
                      - Du timer 0 pour la boucle de r�gulation
                  - Le programme complet d'une boucle de r�gulation.
                    Les valeurs des coefficients Kp et Ti ne sont pas
                    param�tr�s avec la bonne valeur.

###########################################################################*/

// Included Files
#include "f28x_project.h"
#include <math.h>
#include "eqep_ex2_calculation.h"

// Defines
#define EPWM_PERIOD                     1000U
#define EPWM_DEADBAND                   10U
#define CONVERT_COEF_DCBUSVOLTAGEM2     0.00005128205f // !!! VOLTAGE TODO DCBus 0-3.3V -> 0-60V
#define CONVERT_COEF_PHASEUCURRENTM2    0.00005128205f // !!! VOLTAGE TODO PhaseUCurrent 0-3.3V -> -20-+20A
#define CONVERT_COEF_PHASEVCURRENTM2    0.00005128205f // !!! VOLTAGE TODO PhaseVCurrent 0-3.3V -> -20-+20A
#define SQRT3                           1.73205080756f
#define DIV_SQRT3                       0.57735026918f


#define MECH_SCALER     16776   // .9999 / 4000 converted to IQ26 fixed point format
// See Equation 5 in eqep_ex2_calculation.c
#define SPEED_SCALER    ((((uint64_t)32 * 96000000 / 64) * 60) / (24000000))

#define BASE_RPM        6000    // Base/max rpm is 6000rpm

// Editable Globals
float Kp_theta           = 1.0f;    // Gain du r�gulateur de position TODO Kp_theta
float Kp_w               = 1.0f;    // Gain du r�gulateur de vitesse TODO Kp_w
float Gi_w               = 0.0f;    // 1/Ti du r�gulateur de vitesse TODO Gi_w
float Wmax               = 1.0f;    // Vitesse maximale [Rad/s] TODO vitesse max
float Kp_i               = 1.0f;    // Gain du r�gulateur de courant TODO Kp_i
float Gi_i               = 0.0f;    // 1/Ti du r�gulateur de courant TODO Gi_i
float Imax               = 1.0f;    // Courant maximal [A] TODO courant max
float Umax               = 1.0f;    // Tension maximale [V] TODO tension max

// Not Editable Globals
float h                  = 0.0005f; // P�riode d'�chantillonnage du cycle de r�gulation
float EPwm1DutyCycle     = 0.0f;    // Rapport cyclique initial du PWM 1 du moteur 2
float EPwm2DutyCycle     = 0.0f;    // Rapport cyclique initial du PWM 2 du moteur 2
float EPwm3DutyCycle     = 0.0f;    // Rapport cyclique initial du PWM 3 du moteur 2
float DCBusVoltageM2     = 0.0f;    // Mesure de tension d'entr�e du pont triphas�
float PhaseUCurrentM2    = 0.0f;    // Mesure du courant de la phase U du moteur
float PhaseVCurrentM2    = 0.0f;    // Mesure du courant de la phase V du moteur
float consigne           = 0.0f;    // Consigne de position angulaire du rotor du moteur
float thetaMecanique     = 0.0f;    // Position angulaire du rotor du moteur
float thetaMecaniquePrev = 0.0f;    // Position angulaire pr�c�dente du rotor du moteur
float delta_theta        = 0.0f;    // Difference entre la position angulaire actuelle et la pr�c�dente
float thetaElectrique    = 0.0f;    // Position angulaire �lectrique du moteur
float e_theta            = 0.0f;    // Erreur de position
float wc                 = 0.0f;    // Consigne de vitesse
float wf                 = 0.0f;    // Sortie du filtre sur la mesure de vitesse
float ew                 = 0.0f;    // Erreur de vitesse
float kpew               = 0.0f;    // Variable temporaire pour la r�gulation de vitesse
float int_w              = 0.0f;    // Variable d'int�gration du r�gulateur de vitesse
float iqc                = 0.0f;    // Consigne de courant "q"
float iqcp               = 0.0f;    // Consigne de courant "q" avant saturation
float int_iq             = 0.0f;    // Variable d'int�gration du r�gulateur du courant "q"
float uqc                = 0.0f;    // Consigne de tension "q"
float uqcp               = 0.0f;    // Consigne de tension "q" avant saturation
float int_id             = 0.0f;    // Variable d'int�gration du r�gulateur du courant "d"
float udc                = 0.0f;    // Consigne de tension "d"
float udcp               = 0.0f;    // Consigne de tension "d" avant saturation
float i_alpha, i_beta, idm, iqm;    // Variables pour la transform�e de Park
float eiq, kpeiq;                   // Variable temporaire pour la r�gulation du courant "q"
float eid, kpeid;                   // Variable temporaire pour la r�gulation du courant "d"
float usa, usb;                     // Variables pour la transform�e de Park inverse
float divBusDC, h1, h2;             // Variables pour le calcul des rapports cycliques des PWMs
float sinThetaElectrique;           // Variable trigonom�trique pour la position angulaire du moteur
float cosThetaElectrique;           // Variable trigonom�trique pour la position angulaire du moteur

uint32_t count           = 0;       // counter to check measurement gets saturated

PosSpeed_Object posSpeed =
{
    0, 0, 0, 0,     // Initialize outputs to zero
    MECH_SCALER,    // mechScaler
    2,              // polePairs
    0,              // Angular offset between encoder and Phase A
    SPEED_SCALER,   // speedScaler
    0,              // Initialize output to zero
    6000,           // Max RPM
    0, 0, 0, 0      // Initialize outputs to zero
};


// Function Prototypes
void InitEPwm1(void);
void InitEPwm2(void);
void InitEPwm3(void);
void EditEPwmDutyCycle(void);
void ConfigureADC(void);
void SetupADCEpwm(void);
void InitEQep3(void);
void InitEQep3Gpio(void);

// Interrupt Prototypes
__interrupt void cpuTimer0ISR(void);
__interrupt void adcd1_isr(void);
__interrupt void adcd2_isr(void);
__interrupt void adcd3_isr(void);

// Main
void main(void)
{
    // Initialize System Control: PLL, WatchDog, enable Peripheral Clocks
    InitSysCtrl();

    // Initialize GPIO
    InitGpio();

    // Enable PWM1, PWM2 and PWM3
    CpuSysRegs.PCLKCR2.bit.EPWM1=1;
    CpuSysRegs.PCLKCR2.bit.EPWM2=1;
    CpuSysRegs.PCLKCR2.bit.EPWM3=1;

    // Init GPIO pins for ePWM1, ePWM2, ePWM3, EQEP3
    InitEPwm1Gpio();
    InitEPwm2Gpio();
    InitEPwm3Gpio();
    InitEQep3Gpio();

    // Disable CPU interrupts.
    DINT;

    // Initialize the PIE control registers to their default state.
    InitPieCtrl();

    // Disable CPU interrupts and clear all CPU interrupt flags:
    IER = 0x0000;
    IFR = 0x0000;

    // Initialize the PIE vector table with pointers to the shell ISR.
    InitPieVectTable();

    EALLOW;
    PieVectTable.ADCD1_INT = &adcd1_isr; //function for ADCD interrupt 1
    PieVectTable.ADCD2_INT = &adcd2_isr; //function for ADCD interrupt 2
    PieVectTable.ADCD3_INT = &adcd3_isr; //function for ADCD interrupt 3
    EDIS;

    ConfigureADC(); // Configure the ADCs and power them up


    // Initialize EPWM 1,2,3
    EALLOW;
    CpuSysRegs.PCLKCR0.bit.TBCLKSYNC =0;
    EDIS;
    InitEPwm1();
    InitEPwm2();
    InitEPwm3();
    EALLOW;
    CpuSysRegs.PCLKCR0.bit.TBCLKSYNC =1;
    EDIS;

    SetupADCEpwm(); // Setup the ADCs for ePWM triggered conversions

    // Initialize Timer 0
    EALLOW;
    PieVectTable.TIMER0_INT = &cpuTimer0ISR;
    EDIS;
    InitCpuTimers();
    ConfigCpuTimer(&CpuTimer0, 96, 500); // SYSCLK = 96MHz, Timer 1ms
    CpuTimer0Regs.TCR.all = 0x4000;

    // Enable global Interrupts and higher priority real-time debug events:
    IER |= M_INT1;  // CPU-Timer 0 & ADCD1 are on group 1 interrupts
    IER |= M_INT10; // ADCD2 & ADCD3 are on group 10 interrupts

    PieCtrlRegs.PIEIER1.bit.INTx6 = 1;      // Enable PIE: Group  1 interrupt  6 (ADCD1)
    PieCtrlRegs.PIEIER1.bit.INTx7 = 1;      // Enable PIE: Group  1 interrupt  7 (CPU-Timer 0)
    PieCtrlRegs.PIEIER10.bit.INTx14 = 1;    // Enable PIE: Group 10 interrupt 14 (ADCD2)
    PieCtrlRegs.PIEIER10.bit.INTx15 = 1;    // Enable PIE: Group 10 interrupt 15 (ADCD3)

    EINT;  // Enable Global interrupt INTM
    ERTM;  // Enable Global realtime interrupt DBGM

    InitEQep3();

    // Set duty cycles
    EPwm1DutyCycle = 0.5;
    EPwm2DutyCycle = 0.5;
    EPwm3DutyCycle = 0.3;
    EditEPwmDutyCycle();

    // Step 6. IDLE loop. Just sit and loop forever (optional):
    for(;;)
    {
        asm ("          NOP");
    }
}

// Initialize EPWM1 configuration
void InitEPwm1()
{
    EALLOW;
    // SOC for ADC
    EPwm1Regs.ETSEL.bit.SOCAEN      = 1;                // Enable SOC on A group
    EPwm1Regs.ETSEL.bit.SOCASEL     = 2;                // Select SOC on mode " time-base counter equal to period"
    EPwm1Regs.ETPS.bit.SOCAPRD      = 1;                // Generate pulse on 1st event

    EPwm1Regs.TBPRD                 = EPWM_PERIOD;      // Set timer period
    EPwm1Regs.TBPHS.bit.TBPHS       = 0x0000;           // Phase is 0
    EPwm1Regs.TBCTR                 = 0x0000;           // Clear counter
    // Setup TBCLK
    EPwm1Regs.TBCTL.bit.CTRMODE     = TB_COUNT_UPDOWN;  // Count up
    EPwm1Regs.TBCTL.bit.PHSEN       = TB_DISABLE;       // Disable phase loading
    EPwm1Regs.TBCTL.bit.HSPCLKDIV   = TB_DIV1;          // Clock ratio to SYSCLKOUT
    EPwm1Regs.TBCTL.bit.CLKDIV      = TB_DIV1;
    // Set Sync
    EPwm1Regs.CMPCTL.bit.SHDWAMODE  = CC_SHADOW;        // Load registers every ZERO
    EPwm1Regs.CMPCTL.bit.SHDWBMODE  = CC_SHADOW;
    EPwm1Regs.CMPCTL.bit.LOADAMODE  = CC_CTR_ZERO;
    EPwm1Regs.CMPCTL.bit.LOADBMODE  = CC_CTR_ZERO;
    // Set actions
    EPwm1Regs.AQCTLA.bit.CAU        = AQ_SET;           // Set PWM1A on Zero
    EPwm1Regs.AQCTLA.bit.CAD        = AQ_CLEAR;
    EPwm1Regs.AQCTLB.bit.CAU        = AQ_CLEAR;         // Set PWM1A on Zero
    EPwm1Regs.AQCTLB.bit.CAD        = AQ_SET;
    // Active low complementary PWMs - Setup the deadband
    EPwm1Regs.DBCTL.bit.OUT_MODE    = DB_FULL_ENABLE;
    EPwm1Regs.DBCTL.bit.POLSEL      = DB_ACTV_LOC;
    EPwm1Regs.DBCTL.bit.IN_MODE     = DBA_ALL;
    EPwm1Regs.DBRED.bit.DBRED       = EPWM_DEADBAND;
    EPwm1Regs.DBFED.bit.DBFED       = EPWM_DEADBAND;
    EDIS;
}

// Initialize EPWM2 configuration
void InitEPwm2()
{
    EALLOW;
    // SOC for ADC
    EPwm2Regs.ETSEL.bit.SOCAEN      = 1;                // Enable SOC on A group
    EPwm2Regs.ETSEL.bit.SOCASEL     = 2;                // Select SOC on mode " time-base counter equal to period"
    EPwm2Regs.ETPS.bit.SOCAPRD      = 1;                // Generate pulse on 1st event

    EPwm2Regs.TBPRD                 = EPWM_PERIOD;      // Set timer period
    EPwm2Regs.TBPHS.bit.TBPHS       = 0x0000;           // Phase is 0
    EPwm2Regs.TBCTR                 = 0x0000;           // Clear counter
    // Setup TBCLK
    EPwm2Regs.TBCTL.bit.CTRMODE     = TB_COUNT_UPDOWN;  // Count up
    EPwm2Regs.TBCTL.bit.PHSEN       = TB_DISABLE;       // Disable phase loading
    EPwm2Regs.TBCTL.bit.HSPCLKDIV   = TB_DIV1;          // Clock ratio to SYSCLKOUT
    EPwm2Regs.TBCTL.bit.CLKDIV      = TB_DIV1;
    // Set actions
    EPwm2Regs.AQCTLA.bit.CAU        = AQ_SET;           // Set PWM2A on Zero
    EPwm2Regs.AQCTLA.bit.CAD        = AQ_CLEAR;
    EPwm2Regs.AQCTLB.bit.CAU        = AQ_CLEAR;         // Set PWM2A on Zero
    EPwm2Regs.AQCTLB.bit.CAD        = AQ_SET;
    // Active low complementary PWMs - Setup the deadband
    EPwm2Regs.DBCTL.bit.OUT_MODE    = DB_FULL_ENABLE;
    EPwm2Regs.DBCTL.bit.POLSEL      = DB_ACTV_LOC;
    EPwm2Regs.DBCTL.bit.IN_MODE     = DBA_ALL;
    EPwm2Regs.DBRED.bit.DBRED       = EPWM_DEADBAND;
    EPwm2Regs.DBFED.bit.DBFED       = EPWM_DEADBAND;
    EDIS;
}

// Initialize EPWM3 configuration
void InitEPwm3()
{
    EALLOW;
    // SOC for ADC
    EPwm3Regs.ETSEL.bit.SOCAEN      = 1;                // Enable SOC on A group
    EPwm3Regs.ETSEL.bit.SOCASEL     = 2;                // Select SOC on mode " time-base counter equal to period"
    EPwm3Regs.ETPS.bit.SOCAPRD      = 1;                // Generate pulse on 1st event

    EPwm3Regs.TBPRD                 = EPWM_PERIOD;      // Set timer period
    EPwm3Regs.TBPHS.bit.TBPHS       = 0x0000;           // Phase is 0
    EPwm3Regs.TBCTR                 = 0x0000;           // Clear counter
    // Setup TBCLK
    EPwm3Regs.TBCTL.bit.CTRMODE     = TB_COUNT_UPDOWN;  // Count up
    EPwm3Regs.TBCTL.bit.PHSEN       = TB_DISABLE;       // Disable phase loading
    EPwm3Regs.TBCTL.bit.HSPCLKDIV   = TB_DIV1;          // Clock ratio to SYSCLKOUT
    EPwm3Regs.TBCTL.bit.CLKDIV      = TB_DIV1;
    // Set actions
    EPwm3Regs.AQCTLA.bit.CAU        = AQ_SET;           // Set PWM3A on Zero
    EPwm3Regs.AQCTLA.bit.CAD        = AQ_CLEAR;
    EPwm3Regs.AQCTLB.bit.CAU        = AQ_CLEAR;         // Set PWM3A on Zero
    EPwm3Regs.AQCTLB.bit.CAD        = AQ_SET;
    // Active low complementary PWMs - Setup the deadband
    EPwm3Regs.DBCTL.bit.OUT_MODE    = DB_FULL_ENABLE;
    EPwm3Regs.DBCTL.bit.POLSEL      = DB_ACTV_LOC;
    EPwm3Regs.DBCTL.bit.IN_MODE     = DBA_ALL;
    EPwm3Regs.DBRED.bit.DBRED       = EPWM_DEADBAND;
    EPwm3Regs.DBFED.bit.DBFED       = EPWM_DEADBAND;
    EDIS;
}

// Change Duty Cycle of EPWM 1,2,3
void EditEPwmDutyCycle(void)
{
    EPwm1Regs.CMPA.bit.CMPA = (unsigned int)((1.0f - EPwm1DutyCycle) * EPWM_PERIOD);
    EPwm2Regs.CMPA.bit.CMPA = (unsigned int)((1.0f - EPwm2DutyCycle) * EPWM_PERIOD);
    EPwm3Regs.CMPA.bit.CMPA = (unsigned int)((1.0f - EPwm3DutyCycle) * EPWM_PERIOD);
}

// ConfigureADC - Write ADC configurations and power up the ADC for both
//                ADC A and ADC B
void ConfigureADC(void)
{
    EALLOW;

    // Write configurations
    AdcdRegs.ADCCTL2.bit.PRESCALE = 6; //set ADCCLK divider to 4
    AdcSetMode(ADC_ADCD, ADC_RESOLUTION_16BIT, ADC_SIGNALMODE_SINGLE);

    // Set pulse positions to late
    AdcdRegs.ADCCTL1.bit.INTPULSEPOS = 1;

    // Power up the ADC
    AdcdRegs.ADCCTL1.bit.ADCPWDNZ = 1;

    // Delay for 1ms to allow ADC time to power up
    DELAY_US(1000);

    EDIS;
}

// SetupADCEpwm - Setup ADC EPWM acquisition window
void SetupADCEpwm()
{
    Uint16 acqps = 63; //resolution : 12bits = 14 (75ns), 16bits = 63 (320ns)

    EALLOW;
    // Interrupt 1
    AdcdRegs.ADCSOC0CTL.bit.CHSEL       = 1;        //SOC0 will convert pin D1
    AdcdRegs.ADCSOC0CTL.bit.ACQPS       = acqps;    //sample window
    AdcdRegs.ADCSOC0CTL.bit.TRIGSEL     = 9;        //trigger on ePWM3 SOCA/C
    AdcdRegs.ADCINTSEL1N2.bit.INT1SEL   = 0;        //end of SOC0 will set INT1 flag
    AdcdRegs.ADCINTSEL1N2.bit.INT1E     = 1;        //enable INT1 flag
    AdcdRegs.ADCINTFLGCLR.bit.ADCINT1   = 1;        //make sure INT1 flag is cleared
    // Interrupt 2
    AdcdRegs.ADCSOC1CTL.bit.CHSEL       = 14;       //SOC1 will convert pin D14
    AdcdRegs.ADCSOC1CTL.bit.ACQPS       = acqps;    //sample window
    AdcdRegs.ADCSOC1CTL.bit.TRIGSEL     = 5;        //trigger on ePWM1 SOCA/C
    AdcdRegs.ADCINTSEL1N2.bit.INT2SEL   = 1;        //end of SOC1 will set INT2 flag
    AdcdRegs.ADCINTSEL1N2.bit.INT2E     = 1;        //enable INT2 flag
    AdcdRegs.ADCINTFLGCLR.bit.ADCINT2   = 1;        //make sure INT2 flag is cleared
    // Interrupt 3
    AdcdRegs.ADCSOC2CTL.bit.CHSEL       = 15;       //SOC2 will convert pin D15
    AdcdRegs.ADCSOC2CTL.bit.ACQPS       = acqps;    //sample window
    AdcdRegs.ADCSOC2CTL.bit.TRIGSEL     = 7;        //trigger on ePWM2 SOCA/C
    AdcdRegs.ADCINTSEL3N4.bit.INT3SEL   = 2;        //end of SOC2 will set INT3 flag
    AdcdRegs.ADCINTSEL3N4.bit.INT3E     = 1;        //enable INT3 flag
    AdcdRegs.ADCINTFLGCLR.bit.ADCINT3   = 1;        //make sure INT3 flag is cleared
    EDIS;
}

void InitEQep3()
{
    EQep3Regs.QDECCTL.bit.XCR       = 1;            // 1x resolution
    EQep3Regs.QDECCTL.bit.SWAP      = 0;
    EQep3Regs.QDECCTL.bit.QSRC      = 0;

    EQep3Regs.QMACTRL.bit.MODE      = 0;            // QMA module bypassed

    EQep3Regs.QPOSMAX               = 0xFFFFFFFF;
    EQep3Regs.QPOSINIT              = 0;
    EQep3Regs.QUPRD                 = 24000;        // Period for unit timer

    EQep3Regs.QEPCTL.bit.UTE        = 1;            // Enable unit timer
    EQep3Regs.QEPCTL.bit.FREE_SOFT  = 2;
    EQep3Regs.QEPCTL.bit.PCRM       = 0;            // Reset on index event
    EQep3Regs.QEPCTL.bit.QCLM       = 1;
    EQep3Regs.QEPCTL.bit.IEL        = 0;
    EQep3Regs.QEPCTL.bit.SEL        = 0;
    EQep3Regs.QEPCTL.bit.SEI        = 2;
    EQep3Regs.QEPCTL.bit.QPEN       = 1;            // Enable counter

    EQep3Regs.QCAPCTL.bit.UPPS      = 5;            // Unit position event divider (5 = QCLK/32)
    EQep3Regs.QCAPCTL.bit.CCPS      = 6;            // Capture clock divider (6 = SYSCLKOUT/64)
    EQep3Regs.QCAPCTL.bit.CEN       = 1;            // Enable edge capture
}

void InitEQep3Gpio(void)
{
    EALLOW;

    GpioCtrlRegs.GPBPUD.bit.GPIO62 = 1;   // Disable pull-up on GPIO62
    GpioCtrlRegs.GPBPUD.bit.GPIO63 = 1;   // Disable pull-up on GPIO63
    GpioCtrlRegs.GPCPUD.bit.GPIO65 = 1;   // Disable pull-up on GPIO65

    // Set EQEP mode for GPIO 62, 63, 65
    GpioCtrlRegs.GPBGMUX2.bit.GPIO62 = 1;
    GpioCtrlRegs.GPBMUX2.bit.GPIO62 = 1;
    GpioCtrlRegs.GPBGMUX2.bit.GPIO63 = 1;
    GpioCtrlRegs.GPBMUX2.bit.GPIO63 = 1;
    GpioCtrlRegs.GPCGMUX1.bit.GPIO65 = 1;
    GpioCtrlRegs.GPCMUX1.bit.GPIO65 = 1;

    EDIS;
}


// cpuTimer0ISR - CPU Timer0 ISR with interrupt counter
__interrupt void cpuTimer0ISR(void)
{

    // Calcul de la position du rotor
    PosSpeed_calculate(&posSpeed, &count);

    sinThetaElectrique = sinf(posSpeed.thetaElec);
    cosThetaElectrique = 1.0 - sinThetaElectrique * sinThetaElectrique;

    //###################################################################

    // Transform�e de Park
    i_alpha = PhaseUCurrentM2;
    i_beta  = DIV_SQRT3 * (PhaseUCurrentM2 + 2 * PhaseVCurrentM2);
    idm     =  cosThetaElectrique * i_alpha + sinThetaElectrique * i_beta;
    iqm     = -sinThetaElectrique * i_alpha + cosThetaElectrique * i_beta;

    //###################################################################

    // R�gulateur P de position
    e_theta = consigne - posSpeed.thetaMech;
    wc      = e_theta * Kp_theta;
    if (wc > Wmax)  { wc =  Wmax; }
    if (wc < -Wmax) { wc = -Wmax; }

    //###################################################################

    // R�gulateur PI de vitesse
    ew     = wc - wf;
    kpew   = ew * Kp_w;
    int_w += (kpew - (iqcp - iqc)) * Gi_w * h;
    iqcp   = kpew + int_w;
    iqc    = iqcp;
    if (iqc > Imax)  { iqc =  Imax; }
    if (iqc < -Imax) { iqc = -Imax; }

    //###################################################################

    // Regulateurs PI pour les courants du moteur
    eiq     = iqc - iqm;
    kpeiq   = eiq * Kp_i;
    int_iq += (kpeiq - (uqcp - uqc)) * Gi_i * h;
    uqcp    = kpeiq + int_iq;
    uqc     = uqcp;
    if (uqc >  Umax) { uqc =  Umax; }
    if (uqc < -Umax) { uqc = -Umax; }

    eid     = 0.0 - idm;
    kpeid   = eid * Kp_i;
    int_id += (kpeid - (udcp - udc)) * Gi_i * h;
    udcp    = kpeid + int_id;
    udc     = udcp;
    if (udc>Umax)  { udc =  Umax; }
    if (udc<-Umax) { udc = -Umax; }

    //###################################################################

    // Transform�e de Park inverse
    usa = cosThetaElectrique * udc - sinThetaElectrique * uqc;
    usb = sinThetaElectrique * udc + cosThetaElectrique * uqc;

    //###################################################################

    // Calcul des rapports cycliques avec la m�thode vectorielle.
    EPwm1DutyCycle = 1.0;
    EPwm2DutyCycle = 1.0;
    EPwm3DutyCycle = 1.0;
    divBusDC = 1.0 / DCBusVoltageM2;
    h1 = 1.5 * usa * divBusDC;
    h2 = 0.5 * SQRT3 * usb * divBusDC;
    if (h2 >= 0.0) {
        if (h2 < h1) { // SECTEUR 1
            EPwm1DutyCycle += (  h1 +       h2);
            EPwm2DutyCycle += (- h1 + 3.0 * h2);
            EPwm3DutyCycle += (- h1 -       h2);
        } else {
            if (h2 > -h1) { // SECTEUR 2
                EPwm1DutyCycle += (2.0 * h2);
                EPwm2DutyCycle += (2.0 * h1);
                EPwm3DutyCycle += (2.0 * h2);
            } else { // SECTEUR 3
                EPwm1DutyCycle += (- h1 +       h2);
                EPwm2DutyCycle += (- h1 - 3.0 * h2);
                EPwm3DutyCycle += (  h1 -       h2);
            }
        }
    } else {
        if (h2 < -h1) {
            if (h2 > h1) { // SECTEUR 4
                EPwm1DutyCycle += (- h1 -       h2);
                EPwm2DutyCycle += (- h1 + 3.0 * h2);
                EPwm3DutyCycle += (  h1 +       h2);
            } else { // SECTEUR 5
                EPwm1DutyCycle += (- 2.0 * h2);
                EPwm2DutyCycle += (  2.0 * h1);
                EPwm3DutyCycle += (  2.0 * h2);
            }
        } else { // SECTEUR 6
            EPwm1DutyCycle += (  h1 -       h2);
            EPwm2DutyCycle += (- h1 - 3.0 * h2);
            EPwm3DutyCycle += (- h1 +       h2);
        }
    }
    EPwm1DutyCycle *= 0.5;
    EPwm2DutyCycle *= 0.5;
    EPwm3DutyCycle *= 0.5;
    EditEPwmDutyCycle();

    //###################################################################

    // Acknowledge this interrupt to receive more interrupts from group 1
    PieCtrlRegs.PIEACK.all = PIEACK_GROUP1;
}

// adcd1_isr - Read ADC in ISR
__interrupt void adcd1_isr(void)
{
    // Read ADC & Convert value
    DCBusVoltageM2  = CONVERT_COEF_DCBUSVOLTAGEM2 * AdcdResultRegs.ADCRESULT0; // Result of SOC 0

    AdcdRegs.ADCINTFLGCLR.bit.ADCINT1 = 1; //clear INT1 flag

    // Check if overflow has occurred
    if(1 == AdcdRegs.ADCINTOVF.bit.ADCINT1)
    {
        AdcdRegs.ADCINTOVFCLR.bit.ADCINT1 = 1; //clear INT1 overflow flag
        AdcdRegs.ADCINTFLGCLR.bit.ADCINT1 = 1; //clear INT1 flag
    }

    PieCtrlRegs.PIEACK.all = PIEACK_GROUP1;
}

// adcd2_isr - Read ADC in ISR
__interrupt void adcd2_isr(void)
{
    // Read ADC & Convert value
    PhaseUCurrentM2 = CONVERT_COEF_PHASEUCURRENTM2 * AdcdResultRegs.ADCRESULT1; // Result of SOC 1

    AdcdRegs.ADCINTFLGCLR.bit.ADCINT2 = 1; //clear INT2 flag

    // Check if overflow has occurred
    if(1 == AdcdRegs.ADCINTOVF.bit.ADCINT2)
    {
        AdcdRegs.ADCINTOVFCLR.bit.ADCINT2 = 1; //clear INT2 overflow flag
        AdcdRegs.ADCINTFLGCLR.bit.ADCINT2 = 1; //clear INT2 flag
    }

    PieCtrlRegs.PIEACK.all = PIEACK_GROUP10;
}

// adcd3_isr - Read ADC in ISR
__interrupt void adcd3_isr(void)
{
    // Read ADC & Convert value
    PhaseVCurrentM2 = CONVERT_COEF_PHASEVCURRENTM2 * AdcdResultRegs.ADCRESULT2; // Result of SOC 2

    AdcdRegs.ADCINTFLGCLR.bit.ADCINT3 = 1; //clear INT3 flag

    // Check if overflow has occurred
    if(1 == AdcdRegs.ADCINTOVF.bit.ADCINT3)
    {
        AdcdRegs.ADCINTOVFCLR.bit.ADCINT3 = 1; //clear INT3 overflow flag
        AdcdRegs.ADCINTFLGCLR.bit.ADCINT3 = 1; //clear INT3 flag
    }

    PieCtrlRegs.PIEACK.all = PIEACK_GROUP10;
}
